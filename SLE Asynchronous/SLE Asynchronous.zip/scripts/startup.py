import os

def startText():
	# Start up text
	os.system('cls')
	print("This python script was written and coded by TimeTravelPenguin")
	print("Note that some foreign characters may display incorrectly, but should export correctly!\n")
	print("For more, goto: https://SLE.pengu.space\n")
	print("==========================================================================\n")
	
	os.system('title Connecting to Speedrun.com API...')